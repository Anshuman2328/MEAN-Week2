var express = require("express");
var app = express();
var port = 12345;
var bodyParser = require("body-parser");
var path = require("path");


// ****************** This is needed to use json *******************
app.use(bodyParser.json());
// *****************************************************



// ***************** Express Setting *****************
app.use(express.static(path.join(__dirname, "./static")));
app.set("views", path.join(__dirname, "./views"));
// *****************************************************



// ***************** Mongoose Setting ****************
var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/my_task");

var Schema = mongoose.Schema;

var TaskSchema = mongoose.Schema({
    title : {
        type : String,
        required: true
    },
    description : {
        type: String,
        default : ""
    },
    completed : {
        type: Boolean,
        default : false
    },
},
{
    timestamps : true
});

mongoose.model("Task", TaskSchema);

var Task = mongoose.model("Task");

mongoose.Promise = global.Promise;
// *****************************************************



// ********************* Routing *********************



// this is to show all the data in json
app.get("/tasks", function (request, response) {
    Task.find({}, function (error, data) {
        if (error) {
            console.log(error);
            response.json({
                message : "Error",
                error : error
            });
        } else {
            console.log(data);
            response.json({
                message : "My Dear Watson, Elementary!!!!!",
                data : data
            });
        };
    });
});


// this gets just one object from the data using the id
app.get("/tasks/:id", function (request, response) {
    Task.findOne({
        _id : request.params.id
    }, function (error, data) {
        if (error) {
            console.log(error);
            response.json({
                message : "Error",
                error : error
            });
        } else {
            console.log(data);
            response.json({
                message : "We rock here at 221B Baker Street, London, UK,   You are now moving up in Life Watson",
                data : data
            });
        };
    });
});




// creating/adding a new object in db
app.post("/tasks", function (request, response) {
    console.log("POST DATA : " + request.body);
    var task = new Task({
        title : request.body.title,
        description : request.body.description,
        completed : request.body.completed
    });
    task.save( function (error, data) {
        if (error) {
            console.log(error);
            response.json({
                message : "Error",
                error : error
            });
        } else {
            console.log("Successfully saved your data!");
            response.json({
                message : "Add this to the collection of the Mysteries Solved Dear Watson!!!!!",
                data : data
            });
        };
    });
});




// this is how to update the document/record in the collection/model 
app.put("/tasks/:id", function (request, response) {
    console.log(request.params.id);
    Task.update({
        _id : request.params.id
    }, {
        title : request.body.title,
        description : request.body.description,
        completed : request.body.completed
    }, function (error, data) {
        if (error) {
            console.log(error);
            response.json({
                message : "Error",
                error : error
            });
        } else {
            console.log("Successfully updated your data!");
            response.json({
                message : "Dear USER!! or should I Say : My Dear Watson, Sherlock Has Solved This Mystery",
                data : data
            });
        }
    });
});





app.delete("/tasks/:id", function (request, response) {
    Task.remove({
        _id : request.params.id
    }, function (error, data) {
        if (error) {
            console.log(error);
            response.json({
                message : "Error",
                error : error
            });
        } else {
            console.log("Successfully removed from database and you have been killed, Ouch");
            response.json({
                message : "You were Killed by the User, Ouch",
                data : data
            });
        };
    });
});




// *****************************************************



// ******************** Server Up ********************
app.listen(port, function () {
    console.log("listening on port " + port);
});
// *****************************************************








//  below is my original code for Restful API

// const express = require('express');
// const bodyParser = require('body-parser');
// const mongoose = require('mongoose');
// const port = 8000;
// const app = express();
// app.use(bodyParser.json());

// /** Mongoose */
// const Schema = mongoose.Schema;
// mongoose.connect('mongodb://localhost/restful_tasks');
// mongoose.Promise = global.Promise;

// const TaskSchema = new Schema(
//     {
//         title: { type: String },
//         description: { type: String, default: '' },
//         completed: { type: Boolean, default: false },
//     },
//     { timestamps: true }
// );
// mongoose.model('Task', TaskSchema);
// const Task = mongoose.model('Task');
// /** Routes */

// // Render the index page will all tasks
// app.get('/', (req, res) => {
//     Task.find({}, function(err, tasks) {
//         if (err) {
//             console.log('Returned error', err);
//             res.json({ message: 'Error', error: err });
//         } else {
//             res.json({ tasks });
//         }
//     });
// });

// // Show a specific task by id
// app.get('/:id', (req, res) => {
//     Task.findOne({ _id: req.params.id }, function(err, task) {
//         if (err) {
//             console.log('Returned error', err);
//             res.json({ message: 'Error', error: err });
//         } else {
//             res.json({ task });
//         }
//     });
// });

// // Create a new task and redirect to the index page
// app.post('/new', (req, res) => {
//     console.log(req.params);
//     var task = new Task({ title: req.params.title, description: req.params.description });
//     task.save(function(err) {
//         if (err) {
//             res.json({ message: 'Error' });
//         } else {
//             console.log('New task created');
//             res.redirect('/');
//         }
//     });
// });

// // Update a task with paramaters set in the URL
// app.get('/update/:id/:title/:description/:completed', (req, res) => {
//     Task.findOne({ _id: req.params.id }, function(err, task) {
//         if (err) {
//             console.log('Returned error', err);
//             res.json({ message: 'Error', error: err });
//         } else {
//             task.title = req.params.title;
//             task.description = req.params.description;
//             task.completed = req.params.completed;
//             task.save(function(err) {
//                 if (err) {
//                     res.json({ message: 'Error' });
//                 } else {
//                     console.log('Task updated');
//                     res.redirect('/');
//                 }
//             });
//         }
//     });
// });
// // Remove a task by ID
// app.get('/remove/:id', (req, res) => {
//     Task.findOneAndRemove({ _id: req.params.id }, function(err) {
//         if (err) {
//             res.json({ message: 'Error' });
//         } else {
//             res.redirect('/');
//         }
//     });
// });
// /** Server Startup */
// app.listen(port, () => console.log(`Listening on port ${port}`));