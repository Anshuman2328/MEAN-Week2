
// these are requirements, 
var express = require("express");
var app = express();
var bodyparser = require("body-parser");
var port = 8000;



// this is needed to send the json data
app.use(bodyparser.json());



// Connects the database, using mongoose module
require('./server/config/mongoose.js');




// Uses the routes in routes.js under config
// this tells the server where to look for the routes
var routes_setter = require('./server/config/routes.js');
routes_setter(app);




// Runs the server
// this actually runs the server at the mentioned port
app.listen(port, function(){
    console.log(`Ready to go on port 8000 and this port can be changed to any other port if needed...`);
})