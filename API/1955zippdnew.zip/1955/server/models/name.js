// for us to make models we need and require mongoose
var mongoose = require("mongoose");


// this is how a new model/schema is created using mongoose
var NameSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 2},

})

// Our simple schema for each name in this project

mongoose.model("Name", NameSchema)