// this is required in order to tell the route which method in the controller to hit once the app runs
var names = require('../controllers/name.js');

// Here it shows what methods to follow under our
// controller




//  this is what is being exported to the controller. just the routes that we need

module.exports = function(app){
    // Display all names of people born in 1955
    app.get('/', names.index);

    // Adds that name to the database
    app.get('/new/:name', names.add);

    // Removes that name from the database
    app.get('/remove/:name', names.remove);
    
    // Shows just that name
    app.get('/:name', names.show);
}