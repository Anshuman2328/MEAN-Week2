
//  mongoose is required
var mongoose = require("mongoose");

// fs is rquired
var fs = require("fs");

// path is required
var path = require("path");


// Connects the database 1995_api
// this actually connects to our Mongo DB and creates a DB called apiof1955
mongoose.connect('mongodb://localhost/apiof1955');

// this defines the models path. Models live within the models folder within the server
var models_path = path.join(__dirname, './../models');


fs.readdirSync(models_path).forEach(function(file){
    if(file.indexOf('.js') >= 0){
        require(models_path + '/' + file);
    }
});